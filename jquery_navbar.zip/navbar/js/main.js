$(document).ready(function(){
    $('.hb-button').on('click',function(){
        $('nav ul').toggleClass('show');
    })
});